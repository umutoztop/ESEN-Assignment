This project is made on
-c++ 17
-g++
-Ubuntu x86_64