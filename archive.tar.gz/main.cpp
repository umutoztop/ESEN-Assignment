#include <iostream>
#include <ctime> 
#include "source.cpp"


struct Topic1 
{
    char x[100]; 
    char y[100];
};


struct Topic2 
{
    int a, b, c;
};

struct Topic3 
{
    double k;
};


struct SubOne : Subscriber<Topic1>, Subscriber<Topic2> {

    void TopicReceive(std::time_t t1,const Topic2& e) override final 
    {
        std::cout << std::asctime(std::localtime(&t1));
        std::cout << e.a << ' ' << e.b << ' ' << e.c << ' ' << std::endl;
    };

    void TopicReceive(std::time_t t2,const Topic1& e) override final 
    {
        std::cout << std::asctime(std::localtime(&t2));
        std::cout << e.x << ' ' << e.y << std::endl;
    };


};

struct SubTwo : Subscriber<Topic3> {


    void TopicReceive(std::time_t t3,const Topic3& e) override final 
    {
        std::cout << std::asctime(std::localtime(&t3));
        std::cout << e.k << std::endl;
    };

};


int main(int argc, char** argv) {
    Publisher<Topic1, Topic2> Pub1{};
    Publisher<Topic3> Pub2{};

    SubOne s1{};
    SubOne s2{};
    SubTwo s3{};

    Topic1 e1{"Sierra","Nevada"};
    Topic2 e2{30,851,8878};
    Topic3 e3{888.999};


    Pub1.Subscribe<Topic1>(s1);
    Pub1.Subscribe<Topic1>(s2);
    Pub2.Subscribe<Topic3>(s3);

    Pub1.Subscribe<Topic2>(s1);
    Pub1.Subscribe<Topic2>(s2);

    Pub1.Publish(e1);
    Pub1.Publish(e2);
    Pub2.Publish(e3);

    e2.a = 96;
    e2.b = 88;
    e2.c = 9632;


    Pub1.Publish(e2);

    Pub1.Unsubscribe<Topic1>(s1);
    Pub1.Publish(e1);

    return 0;
}