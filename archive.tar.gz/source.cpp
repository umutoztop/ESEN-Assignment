#include <vector>
#include <algorithm>
#include <functional>
#include <ctime> 
#include <mutex>

std::mutex mtx;
std::mutex sem;

//Bu kütüphanede kullanıcı istediği topic'i kendisi istediği gibi tanımlayabilir
//Kullanıcıya bu imkan sunulmuştur

// Subscriber class template
template <typename TopicType>
struct Subscriber 
{ 
    virtual ~Subscriber() = default;
    // Her Subscriber'ın mesajı aldığında farklı bir işlem yapabilmesi için
    // mesaj alınacağında ne yapılacağı kullanıcıya bırakılmıştır.
    // Tanımlanan Topic type ile beraber Timmestap için time inputu eklenmesi gereklidir.
    virtual void TopicReceive(std::time_t t,const TopicType&) {};
};

// Subscriberların tutulduğu Subscribers class template
template <typename SubscriberType>
struct Subscribers 
{
protected:

    // Bir subscriber bir topic'e subscribe olduğunda
    // o subscriberı subscriberların bbulunduğu sıranın en sonuna ekler
    template <typename TopicSubscriber>
    void sub(TopicSubscriber& s) 
    { 
        sem.lock();
        subs_.emplace_back(
            std::reference_wrapper<TopicSubscriber>(s)
            ); 
        sem.unlock();
    }

    // Bir subscriber bir topic'ten unsubscribe olduğunda
    // Subbscriberların arasından silinir ve aradaki boşluklar kapatılır
    template <typename TopicSubscriber>
    void unsub(TopicSubscriber& s) 
    {
        sem.lock();
        subs_.erase(
            std::remove_if(subs_.begin(),subs_.end(),[&s](auto m) {return &m.get() == &s;}),
            subs_.end());
        sem.unlock();
    }

    // Bir mesaj "publish"lendiğinde timestamp alınıp kullanıcının belirlediği 
    // fonksiyon çağırılır ve kullanıcının istediği işlem yapılır  
    template <typename TopicType>
    void publish(const TopicType& e) 
    {
        std::time_t result = std::time(nullptr);
        for (auto s : subs_)
        {
            mtx.lock();
            s.get().TopicReceive(result,e);
            mtx.unlock();
        }
    }

private:
    // std::reference_wrapper'ın kullanılma nedeni bu classın aslında subscriberların
    // kendilerini değil yalnıca pointerlarını tutması ve topic publish edildiğinde
    // onlara ulaşılması
    std::vector<std::reference_wrapper<SubscriberType>> subs_;
};

// Publisher class template
// Bir publisherın bir kaç topic type pubblishleyebilmesi için
// çoklu input type alabilir. 
template <typename... TopicTypes>
struct Publisher : public Subscribers< Subscriber<TopicTypes> >... 
{

    // Topic'e Subscribe olmak isteyen Subscriberların kullandığı API
    template <typename TopicType, typename TopicSubscriber>
    void Subscribe(TopicSubscriber &s) 
    { 
        Subscribers< Subscriber<TopicType> >::sub(s); 
    }

    // Topic'ten Unsubscribe olmak isteyen Subscriberların kullandığı API
    template <typename TopicType, typename TopicSubscriber>
    void Unsubscribe(TopicSubscriber &s) 
    { 
        Subscribers< Subscriber<TopicType> >::unsub(s); 
    }

    // Topic'te yeni bir mmesaj publishlemek isteyen publisherın kullandığı API
    template <typename TopicType>
    void Publish(const TopicType& e) 
    {
        Subscribers< Subscriber<TopicType> >::publish(e); 
    }

};

